# SK ONLINE BUSINESS - Django Project

See LOCAL_SETUP.txt for running locally.
