from django.shortcuts import render, get_object_or_404
from .models import WebsiteSetting
from services.models import Service

def home(request):
    setting = WebsiteSetting.objects.first()
    services = Service.objects.all()
    return render(request, 'home.html', {'setting': setting, 'services': services})

def contact(request):
    setting = WebsiteSetting.objects.first()
    return render(request, 'contact.html', {'setting': setting})
def disclaimer(request):
    setting = WebsiteSetting.objects.first()
    return render(request, 'disclaimer.html', {'setting': setting})
