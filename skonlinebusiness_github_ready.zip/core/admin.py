from django.contrib import admin
from .models import WebsiteSetting
@admin.register(WebsiteSetting)
class WebsiteSettingAdmin(admin.ModelAdmin):
    list_display = ('site_name', 'phone', 'email')
