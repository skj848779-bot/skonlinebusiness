from django.db import models
from django.utils.html import mark_safe

class WebsiteSetting(models.Model):
    site_name = models.CharField(max_length=200, default="SK ONLINE BUSINESS")
    phone = models.CharField(max_length=50, blank=True)
    email = models.EmailField(blank=True)
    logo = models.ImageField(upload_to="logos/", blank=True, null=True)
    banner_text = models.CharField(max_length=255, blank=True)
    about = models.TextField(blank=True)

    def __str__(self):
        return self.site_name
