from django.shortcuts import render, get_object_or_404
from .models import Service

def service_detail(request, slug):
    svc = get_object_or_404(Service, slug=slug)
    return render(request, 'service_detail.html', {'service': svc})

def services_list(request):
    services = Service.objects.all()
    return render(request, 'services_list.html', {'services': services})
